#!/bin/bash
#PBS -l walltime=5:00:00
#PBS -q medium
#PBS -l nodes=8:ppn=16
#PBS -N MoS2-relax-ab-pbe 
#PBS -j oe
#PBS -o oe.txt

module load intel-libs/2017.4.196
module load intel-compiler/2023.2.0
cd "$PBS_O_WORKDIR"
vasp_exec=/home/tuj14891/work/vasp-code/VASP544/vasp544-no-z-relax/bin/vasp_std
mpirun --mca btl '^openib' -np $PBS_NP $vasp_exec
