#!/bin/bash
path1='/home/tuj14891/vasp-work/MoS2/monolayer-using-rectangular-cell/hse-using-hsegeo-relax-abnotc-done-at-owlnest/strain-ex-along-a/ex4.0_ey-1.76/k16162'
job2='geo scf dos'
for job in $job2
do
mkdir $job
cp $path1/$job/CONTCAR $job
cp $path1/$job/POSCAR* $job
cp $path1/$job/INCAR $job
cp $path1/$job/KPOINTS $job
cp $path1/$job/POTCAR $job
cp $path1/$job/OUTCAR $job
cp $path1/$job/vasprun.xml $job
done
